#pragma once

int mcd(int, int);
int simpFrac(int, int);
