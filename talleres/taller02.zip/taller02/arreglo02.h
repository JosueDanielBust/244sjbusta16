/*
 * fichero: arreglo02.h
 */

void imprimirArreglo(char nombre[], int arreglo[], const int n);
void concatenarArreglos(int dest[], int fuente[], const int n);
