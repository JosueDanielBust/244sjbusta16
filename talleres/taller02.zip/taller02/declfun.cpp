#include <iostream>
using namespace std;

void a(int aarg, int barg) {}
char b(unsigned short int aarg, unsigned short barg, unsigned short int carg) { return 0; }
void c(void) {}
bool d(signed long int aarg, signed long int barg, signed long int carg, signed long int darg, signed long int earg, signed long int farg, signed long int garg, signed long int harg, signed long int iarg, signed long int jarg) { return true; }
int e(void) { return 0; }

int
main(void) { return 0; }
