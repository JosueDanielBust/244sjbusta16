#include <iostream>
using namespace std;

int a;
bool b;
float c;
double d;
unsigned long int e;
char f;
signed int g;

int
main(void) {
  int a;
  bool b;
  float c = 10.23;
  double d = 23e+23;
  unsigned long int e = 23430303;
  char f = 10;
  signed int g = f;
  
  return 0;
}
