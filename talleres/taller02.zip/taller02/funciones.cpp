#include <iostream>
using namespace std;

int sumaEnt(int a, int b) { int c = a + b; return c; }
int restaEnt(int a, int b) { int c = a - b; return c; }
int divEnt(int a, int b) { int c = a / b; return c; }
int multEnt(int a, int b) { int c = a * b; return c; }
