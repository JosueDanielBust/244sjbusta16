#include <iostream>
using namespace std;

int main() {
  string p;

  cin >> p;

  int p1 = p[0] % 2;
  int p2 = p[1] % 2;

  if ((p1 + p2) != 2) {
    cout << "negro" << endl;
  } else {
    cout << "blanco" << endl;
  }

  return 0;
}
