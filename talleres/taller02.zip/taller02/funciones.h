#pragma once

int sumaEnt(int, int);
int restaEnt(int, int);
int divEnt(int, int);
int multEnt(int, int);
