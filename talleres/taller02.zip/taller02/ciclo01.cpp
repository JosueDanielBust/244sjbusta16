/*
 * fichero: ciclo01.cpp
 * compilar: $ g++ -o ciclo01 ciclo01.cpp
 *           $ make ciclo01
 * ejecutar: $ ./ciclo01
 */
#include <iostream>

using namespace std;

const int N = 10;

int main() {
  int i;

  i = 0;
  while ((++i < N)) {
    cout << "veces: " << i << endl;
  }

  cout << i << endl;
  return 0;
}
