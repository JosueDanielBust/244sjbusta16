/*
 * fichero: ciclo05.cpp
 * compilar: $ g++ -o ciclo05 ciclo05.cpp
 *           $ make ciclo05
 * ejecutar: $ ./ciclo05
 */
#include <iostream>

using namespace std;

void nada() { }

int main() {
  int x, y = 10, z = 20;

  for (x = 0; x < z + y; x += 5) {
    nada();
  }

  cout << "x: "  << x
       << " y: " << y
       << " z: " << z << endl;

  return 0;
}
