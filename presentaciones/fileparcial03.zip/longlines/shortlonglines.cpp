#include <iostream>
#include <string>

using namespace std;

int
main() {

  /*
   * Inserte el codigo en C++ que procese lineas largas y las
   * convierta en una sola linea.
   */
  return 0;
}
