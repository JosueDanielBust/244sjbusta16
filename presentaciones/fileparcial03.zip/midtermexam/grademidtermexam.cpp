#include <iostream>
#include <fstream>

using namespace std;
int
main(int argc, const char *argv[]) {
  // Inserte el código que procese los
  // ficheros de entrada y procese las notas
  // de cada grupo de estudiantes
  return 0;
}
