
class ParseError < Exception; end
class UnrecognizedTokenException < Exception; end
